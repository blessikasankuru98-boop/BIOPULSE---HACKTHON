from flask import Flask, render_template, jsonify, request
import random

app = Flask(__name__)

# EDUCATIONAL SYNTHETIC DATA ONLY.
# These examples demonstrate how a hypothetical sequence marker might be linked
# to a gene/disease association. They are not patient records or diagnostic results.
SAMPLES = [
    {
        "id": "P-001", "person": "Maya R.", "age": 46, "sample": "Blood sample",
        "sequence": "ACGTACGTAGCTAGCT", "marker": "BRCA1 variant (illustrative)",
        "gene": "BRCA1", "condition": "Hereditary breast/ovarian cancer risk",
        "target": "BRCA1-associated variant marker", "status": "Marker match",
        "strength": 94, "signal": 2.8, "color": "rose",
        "explanation": "The example target guide is designed to recognize a BRCA1-associated sequence marker. A matching signal means the simulated sensor recognized the selected marker—not that cancer is confirmed."
    },
    {
        "id": "P-002", "person": "Arun K.", "age": 61, "sample": "Blood sample",
        "sequence": "TTGACCGTACGATGCA", "marker": "EGFR variant (illustrative)",
        "gene": "EGFR", "condition": "Some non-small-cell lung cancer contexts",
        "target": "EGFR variant marker", "status": "Marker match",
        "strength": 89, "signal": 2.4, "color": "amber",
        "explanation": "EGFR alterations can be clinically relevant in some lung cancers. Real testing requires a validated assay, exact variant identification, and interpretation by a qualified clinician."
    },
    {
        "id": "P-003", "person": "Nina S.", "age": 53, "sample": "Bone marrow sample",
        "sequence": "GCTATCGGATCCGTAA", "marker": "BCR::ABL1 fusion (illustrative)",
        "gene": "BCR::ABL1", "condition": "Chronic myeloid leukemia (CML) association",
        "target": "BCR::ABL1 fusion marker", "status": "Marker match",
        "strength": 97, "signal": 3.1, "color": "violet",
        "explanation": "The BCR::ABL1 fusion is strongly associated with CML. The dashboard uses a fictional sample and a simulated match to demonstrate sensor response."
    },
    {
        "id": "P-004", "person": "Dev P.", "age": 58, "sample": "Tissue sample",
        "sequence": "AACCTGGTAGGCTTAC", "marker": "KRAS variant (illustrative)",
        "gene": "KRAS", "condition": "Relevant in some colorectal, lung and pancreatic cancers",
        "target": "KRAS variant marker", "status": "Marker match",
        "strength": 86, "signal": 2.1, "color": "cyan",
        "explanation": "KRAS variants have different implications depending on the exact variant and cancer type. A gene name alone cannot establish a diagnosis."
    },
    {
        "id": "P-005", "person": "Control sample", "age": None, "sample": "Reference control",
        "sequence": "ACACACACGTGTGTGT", "marker": "No target marker in this demo",
        "gene": "None detected", "condition": "No target match in this simulation",
        "target": "Negative control", "status": "No match",
        "strength": 8, "signal": 0.35, "color": "mint",
        "explanation": "The control demonstrates a low sensor response when the selected target is absent from the simulated sample. This is not proof that a real person is disease-free."
    }
]

@app.route("/")
def index():
    return render_template("index.html", samples=SAMPLES)

@app.route("/api/sample/<sample_id>")
def sample_detail(sample_id):
    sample = next((s for s in SAMPLES if s["id"] == sample_id), None)
    if not sample:
        return jsonify({"error": "Sample not found"}), 404
    # Slight variation makes repeated runs feel dynamic while keeping data illustrative.
    result = dict(sample)
    result["signal"] = round(max(0.15, sample["signal"] + random.uniform(-0.12, 0.12)), 2)
    result["strength"] = max(1, min(99, sample["strength"] + random.randint(-2, 2)))
    result["run_id"] = "SIM-" + str(random.randint(10000, 99999))
    result["disclaimer"] = "Synthetic educational simulation only—not a medical test or diagnosis."
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
