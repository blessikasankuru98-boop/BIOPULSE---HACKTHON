GRAPHENE CRISPR CANCER / DISEASE MARKER DASHBOARD
================================================

IMPORTANT
---------
This is an educational software simulation only. All sample identities, DNA strings,
readings, matching scores and runs are synthetic. It does NOT test real DNA, detect
cancer, diagnose disease, or provide medical advice. Gene associations are simplified
examples for learning. A real result requires a validated clinical assay and qualified
medical interpretation.

FEATURES
--------
- Attractive responsive dark dashboard
- Five fictional samples, including a negative control
- Gene/disease association examples: BRCA1, EGFR, BCR::ABL1 and KRAS
- Select each sample and run a simulated sensor test
- Animated graphene sensor and DNA target interaction
- Dynamic electrical signal trace and simulated match score
- Flask API serving sample results

RUN IN VS CODE (WINDOWS)
-----------------------
1. Extract the ZIP file.
2. In VS Code, choose File > Open Folder and select the extracted
   Graphene_CRISPR_Cancer_Disease_Dashboard folder.
3. Open Terminal > New Terminal.
4. Run:
       py -m pip install -r requirements.txt
       py app.py
5. Open this URL in Chrome:
       http://127.0.0.1:5000

If PowerShell blocks virtual environment activation, you do not need to activate it.
The two commands above work without activating .venv, provided Python is installed.

HOW TO DEMONSTRATE
------------------
1. Click a sample in the left screening queue.
2. Read its illustrative gene marker and associated disease context.
3. Click "Run detection simulation".
4. Observe the animated target interaction, signal trace, and result summary.
5. Select the control sample to compare a low simulated response.

SCIENTIFIC NOTE
---------------
BRCA1 variants can be relevant to inherited breast/ovarian cancer susceptibility;
EGFR alterations can guide treatment in some non-small-cell lung cancers;
BCR::ABL1 fusion is associated with chronic myeloid leukemia; KRAS variants have
different implications across several cancer types. These are gene-level examples,
not a claim that the fictional people have these diseases. Specific variants,
sample type, clinical context and validated methods matter.
