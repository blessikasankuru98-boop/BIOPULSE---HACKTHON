const rows = [...document.querySelectorAll('.sample-row')];
let currentId = 'P-001';
let busy = false;
let trace = Array.from({length:44}, (_,i)=>0.35 + Math.sin(i*.42)*.025);
const canvas = document.getElementById('signalChart');
const ctx = canvas.getContext('2d');

function drawChart(values=trace) {
  const ratio = window.devicePixelRatio || 1;
  const w = canvas.clientWidth || 400, h = 190;
  canvas.width = w*ratio; canvas.height = h*ratio;
  ctx.setTransform(ratio,0,0,ratio,0,0);
  ctx.clearRect(0,0,w,h);
  const pad = {l:12,r:8,t:12,b:15}, cw=w-pad.l-pad.r, ch=h-pad.t-pad.b;
  ctx.strokeStyle = '#1e2d40'; ctx.lineWidth=1;
  for(let i=0;i<5;i++){const y=pad.t+ch*i/4;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();}
  const max = Math.max(3.4, ...values)*1.12, min=0;
  const points=values.map((v,i)=>({x:pad.l+cw*i/(values.length-1),y:pad.t+ch-(v-min)/(max-min)*ch}));
  const grad=ctx.createLinearGradient(0,pad.t,0,h);grad.addColorStop(0,'rgba(77,226,208,.28)');grad.addColorStop(1,'rgba(77,226,208,0)');
  ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.lineTo(points[points.length-1].x,h-pad.b);ctx.lineTo(points[0].x,h-pad.b);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
  ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle='#55e0d0';ctx.lineWidth=2;ctx.shadowColor='#55e0d0';ctx.shadowBlur=7;ctx.stroke();ctx.shadowBlur=0;
  const p=points[points.length-1];ctx.beginPath();ctx.arc(p.x,p.y,3.5,0,Math.PI*2);ctx.fillStyle='#b6fff1';ctx.fill();
}
function initials(name){return name.split(/\s+/).filter(x=>x && x!=='R.' && x!=='K.' && x!=='S.' && x!=='P.').slice(0,2).map(x=>x[0]).join('').toUpperCase() || 'CS';}
async function selectSample(id){
  currentId=id;
  rows.forEach(r=>r.classList.toggle('selected',r.dataset.id===id));
  const res=await fetch(`/api/sample/${id}`);
  const s=await res.json();
  document.getElementById('personInitials').textContent=initials(s.person);
  document.getElementById('personName').textContent=s.person;
  document.getElementById('personMeta').textContent=`${s.id} · ${s.sample}${s.age ? ' · Age '+s.age : ''}`;
  document.getElementById('geneName').textContent=s.gene;
  document.getElementById('conditionText').textContent=s.condition;
  document.getElementById('matchChip').textContent=`${s.strength}% simulated match`;
  document.getElementById('signalValue').innerHTML=`${Number(s.signal).toFixed(2)} <small>mV*</small>`;
  document.getElementById('signalMeterFill').style.width=`${Math.min(100,s.strength)}%`;
  document.getElementById('explanationText').textContent=s.explanation;
  document.getElementById('resultBadge').textContent='READY TO SIMULATE';
  document.getElementById('signalChange').textContent=s.strength>20?'▲ potential target response':'— low baseline response';
  document.getElementById('channelId').textContent='S'+(Number(id.slice(-1))||1);
  document.getElementById('sensorState').textContent='WAITING FOR TARGET';
  document.getElementById('sensorState').className='state-idle';
  document.getElementById('bindingLabel').textContent='TARGET GUIDE READY';
  document.querySelector('.chip-stage').classList.remove('binding');
  document.getElementById('chartStatus').textContent='IDLE';
  document.getElementById('baselineValue').textContent='0.35';
  document.getElementById('peakValue').textContent='—';
  document.getElementById('latestRun').textContent='READY';
  document.getElementById('latestStatus').textContent='Select Run detection';
  trace=Array.from({length:44},(_,i)=>.35+Math.sin(i*.42)*.025);
  drawChart();
}
rows.forEach(r=>r.addEventListener('click',()=>selectSample(r.dataset.id)));
document.getElementById('runButton').addEventListener('click',async()=>{
  if(busy)return;busy=true;
  const btn=document.getElementById('runButton');btn.disabled=true;btn.querySelector('span').textContent='Running sensor simulation…';
  document.getElementById('resultBadge').textContent='ANALYZING';
  document.getElementById('sensorState').textContent='TARGET CONTACT';document.getElementById('sensorState').className='state-active';
  document.getElementById('bindingLabel').textContent='GUIDE / TARGET INTERACTION';
  document.querySelector('.chip-stage').classList.add('binding');
  document.getElementById('chartStatus').textContent='ACQUIRING';
  document.querySelectorAll('.step').forEach((s,i)=>s.classList.toggle('done',i===0));
  const response=await fetch(`/api/sample/${currentId}`);const s=await response.json();
  const peak=Number(s.signal);
  const baseline=.35;
  const target= s.strength>20 ? peak : baseline+.06;
  const n=44;
  trace=Array.from({length:n},(_,i)=>baseline+Math.sin(i*.48)*.025);
  drawChart();
  for(let i=0;i<n;i++){
    const progress=i/(n-1);
    const ramp=progress<.4 ? progress/.4 : 1;
    const value=baseline+(target-baseline)*ramp + (Math.random()-.5)*.06;
    trace[i]=Math.max(.15,value);
    drawChart(trace.slice(0,i+1).concat(Array(Math.max(0,n-i-1)).fill(trace[i])));
    await new Promise(resolve=>setTimeout(resolve,27));
  }
  document.getElementById('signalValue').innerHTML=`${peak.toFixed(2)} <small>mV*</small>`;
  document.getElementById('signalMeterFill').style.width=`${s.strength}%`;
  document.getElementById('matchChip').textContent=`${s.strength}% simulated match`;
  document.getElementById('resultBadge').textContent=s.strength>20?'SIMULATED MATCH':'CONTROL / LOW RESPONSE';
  document.getElementById('signalChange').textContent=s.strength>20?'▲ simulated signal increase':'— low baseline response';
  document.getElementById('latestRun').textContent=s.run_id;
  document.getElementById('latestStatus').textContent=s.strength>20?'Target pattern simulated':'Control pattern simulated';
  document.getElementById('sensorState').textContent='SIGNAL RECORDED';document.getElementById('bindingLabel').textContent=s.strength>20?'SIMULATED TARGET RECOGNITION':'NO TARGET MATCH IN DEMO';
  document.getElementById('chartStatus').textContent='COMPLETE';
  document.getElementById('peakValue').textContent=peak.toFixed(2);
  document.querySelectorAll('.step').forEach(s=>s.classList.add('done'));
  btn.disabled=false;btn.querySelector('span').textContent='Run detection simulation';busy=false;
});
window.addEventListener('resize',()=>drawChart());
drawChart();
